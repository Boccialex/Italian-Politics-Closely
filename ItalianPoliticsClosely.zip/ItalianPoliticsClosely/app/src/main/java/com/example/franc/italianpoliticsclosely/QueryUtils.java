package com.example.franc.italianpoliticsclosely;


import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
/**
 * Helper methods related to requesting and receiving news data from the GUARDIAN.
 */

public class QueryUtils {

    /**
     * Tag for the log messages
     */
    private static final String LOG_TAG = QueryUtils.class.getSimpleName();

    private QueryUtils() {
    }

    public static List<Ipc> fetchIpcData(String requestUrl) {
        Log.i(LOG_TAG, "TEST: fetchIpcData() called ...");
        URL url = createUrl(requestUrl);

        String jsonResponse = null;
        try {
            jsonResponse = makeHttpRequest(url);
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<Ipc> ipcs = extractFeatureFromJson(jsonResponse);
        return ipcs;
    }

    private static URL createUrl(String stringUrl) {
        Log.i(LOG_TAG, "TEST: createUrl()called....");

        URL url = null;
        try {
            url = new URL(stringUrl);
        } catch (MalformedURLException e) {

            e.printStackTrace();
        }
        return url;
    }


 private static String makeHttpRequest(URL url) throws IOException {
        Log.i(LOG_TAG, "TEST: makeHttpRequest()called....");
        String jsonResponse = "";

        if (url == null) {
            return jsonResponse;
        }

        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;
        try {
            Log.i(LOG_TAG,"TEST: url.openConnection() called ...");
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(10000 /* milliseconds */);
            urlConnection.setConnectTimeout(15000 /* milliseconds */);
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            if (urlConnection.getResponseCode() == 200) {
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } else {
                Log.d("Error response code: ", String.valueOf(urlConnection.getResponseCode()));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (inputStream != null) {

                inputStream.close();
            }
        }
        return jsonResponse;
    }


    private static String readFromStream(InputStream inputStream) throws IOException {
        Log.i(LOG_TAG, "TEST: readFromStream()called....");

        StringBuilder output = new StringBuilder();
        if (inputStream != null) {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String line = reader.readLine();
            while (line != null) {
                output.append(line);
                line = reader.readLine();
            }
        }
        return output.toString();
    }

    private static List<Ipc> extractFeatureFromJson(String newsJSON) {
        Log.i(LOG_TAG, "TEST: extractFeatureFromJson()called....");

        if (TextUtils.isEmpty(newsJSON)) {
            return null;
        }

        List<Ipc> ipcs = new ArrayList<>();
        try {
            JSONObject baseJsonResponse = new JSONObject(newsJSON);

            Log.i(LOG_TAG, "TEST: baseJsonResponse.getJSONObject() called ...");
            JSONObject response = baseJsonResponse.getJSONObject("response");
            JSONArray resultsArray = response.getJSONArray("results");

            for (int i = 0; i < resultsArray.length(); i++) {

                JSONObject currentResults = resultsArray.getJSONObject(i);

                String Title = currentResults.getString("webTitle");
                String section = currentResults.getString("sectionName");
                String date = currentResults.getString("webPublicationDate");
                String url = currentResults.getString("webUrl");

                Ipc ipc = new Ipc(Title, section, date, url);

                ipcs.add(ipc);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return ipcs;

    }
}