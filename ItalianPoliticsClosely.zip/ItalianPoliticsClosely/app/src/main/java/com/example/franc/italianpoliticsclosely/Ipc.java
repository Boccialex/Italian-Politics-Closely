package com.example.franc.italianpoliticsclosely;

/**
 * An {@link Ipc} object contains information related to a single earthquake.
 */

public class Ipc {

    /**
     * News' title, author, section, date and web url
     */
    private String mTitle;
    private String mAuthor;
    private String mSection;
    private String mDate;
    private String mUrl;

    /**
     * Constructs a new {@link Ipc} object.
     *
     * @param title              is the head of an article
     * @param author            is the article's author
     * @param section            is the section of the newspaper where it appeared
     * @param date               is the the publication date
     * @param url                is the website URL to find more details about the news
     */
    public Ipc(String title, String author, String section, String date, String url) {
        mTitle = title;
        mAuthor = author;
        mSection = section;
        mDate = date;
        mUrl = url;
    }

    /**
     * Returns the news' title, author, section, date and web url
     */
    public String getTitle() {
        return mTitle;
    }
    public String getAuthor() {
        return mAuthor;
    }
    public String getSection() {
        return mSection;
    }
    public String getDate() {
        return mDate;
    }
    public String getUrl() {
        return mUrl;
    }
}

