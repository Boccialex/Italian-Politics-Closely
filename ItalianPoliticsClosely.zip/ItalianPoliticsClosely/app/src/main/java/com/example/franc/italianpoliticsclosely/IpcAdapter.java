package com.example.franc.italianpoliticsclosely;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class IpcAdapter extends ArrayAdapter<Ipc> {

        /**
         * Constructs a new {@link IpcAdapter}.
         *
         * @param context of the app
         * @param ipcs is the list of news, which is the data source of the adapter
         */
        public IpcAdapter(Context context, List<Ipc> ipcs) {
            super(context, 0, ipcs);
        }

        // Returns a list item view that displays information about the news at the given position in the Ipc list.
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Check if there is an existing list item view (called convertView) that we can reuse,
            // otherwise, if convertView is null, then inflate a new list item layout.
            View listItemView = convertView;
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(
                        R.layout.ipc_list_item, parent, false);
            }

            //Find the TextViews
            TextView title = convertView.findViewById(R.id.title);
            TextView author = convertView.findViewById(R.id.author);
            TextView date = convertView.findViewById(R.id.date);
            TextView section = convertView.findViewById(R.id.section);
            TextView url = convertView.findViewById(R.id.url);

            Ipc currentIpc = getItem(position);
            assert currentIpc != null;
            title.setText(currentIpc.getTitle());
            author.setText(currentIpc.getAuthor());
            date.setText(currentIpc.getDate());
            section.setText(currentIpc.getSection());
            url.setText(currentIpc.getUrl());

            return convertView;
        }
    }

